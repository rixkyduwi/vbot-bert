import torch,time,numpy as np
from flask import jsonify
from transformers import BertTokenizerFast, BertForQuestionAnswering
from datetime import datetime
from . import mysql
import openai
import textwrap,re
import urllib, json,os
import pandas as pd
from dotenv import load_dotenv
load_dotenv()
key = os.environ.get("API_CHATGPT")
#print(key)
openai.api_key = key
device = "cuda" if torch.cuda.is_available() else "cpu" 
torch.device(device) 
modelCheckpoint = "indolem/indobert-base-uncased"

model_directory = os.path.abspath(os.path.join(__file__, "../../bert_model/model.bin")) 
model = torch.load(model_directory,map_location=torch.device('cpu'))
model.to(device)
tokenizer = BertTokenizerFast.from_pretrained(modelCheckpoint)
start_time = time.time()

mengatasi_maag ="cara mengatasinya : Makan secara perlahan, dalam porsi yang kecil Batasi konsumsi makanan pedas dan berlemak, Kurangi minuman berkafein, Hindari obat-obatan yang menyebabkan nyeri lambung, Anda juga bisa mengkonsumsi obat penetraalisir maag seperti Promag, mylanta, polysilane dst. Promag dijual secara bebas dan tersedia dalam bentuk tablet kunyah serta suspensi cair."
mengatasi_influenza="cara mengatasinya : Menjaga daya tahan tubuh agar tidak mudah terserang virus. Misalnya dengan makan teratur, istirahat yang cukup, minum air putih sesuai kebutuhan, berolah raga, dan memiliki gaya hidup yang sehat.Selain itu, menjaga daya tahan tubuh juga dapat juga didukung dengan asupan vitamin terutama Vitamin C yang bisa didapatkan di buah-buahan maupun vitamin yang dijual di toko-toko.Pencegahan lainnya adalah dengan menggunakan masker ditempat umum, terutama bagi yang menderita influenza."
mengatasi_Muntaber="Cara mengatasi : muntaber yang dapat dilakukan dengan mudah adalah terapi rehidrasi dengan cara mengonsumsi banyak cairan terutama air putih. Sementara untuk balita dan anak-anak, pemakaian oralit mungkin bisa langsung diberikan untuk menggantikan cairan yang hilang. Kenapa harus oralit? Karena air biasa tidak memiliki kandungan garam dan nutrisi yang cukup untuk menggantikan cairan yang hilang.Jika diperlukan, dokter biasanya akan meresepkan antibiotika jenis metronidazol yang dikombinasikan dengan sulfametoksazol dan trimetoprim. Obat diare lainnya yang bisa digunakan adalah probiotik. Probiotik bisa digunakan untuk mengobati diare dengan cara melawan bakteri jahat penyebab diare. "
mengatasi_Cacar_air= "cara mengatasinya : Melakukan vaksinasi cacar air, Menjaga kebersihan diri sendiri, pakaian, dan lingkungan, Mengkonsumsi makanan bergizi, Menghindari sumber penularan cacar air."
mengatasi_Tifus="cara mengatasinya : Memastikan kebersihan bahan makanan sebelum memasaknya, Mencuci tangan secara teratur, terutama sebelum dan setelah makanan, Membersihkan luka dan segera mengobatinya, Hindari jajan di pinggir jalan yang terlihat tidak higienis, Menjaga daya tahan tubuh, Memakan yang tinggi protein, rendah serat, lunak, tidak asam,  dan pedas."
mengatasi_Campak="cara mengatasinya : Melakukan vaksinasi ketika masih usia balita."
mengatasi_Pneumonia="cara mengatasinya : Terapi kausal Terapi ini dilakukan dengan cara pemberian obat antibiotik atau obat antijamur. Terapi suportif umum Penanganan ini disesuaikan dengan keadaan pasien, misalnya ketika pemberian terapi oksigen. Terapi inhalasi Dengan cara menyalurkan obat langsung ke paru-paru, terapi ini sangat bermanfaat pada kondisi pasien yang membutuhkan pengobatan segera. Terapi ini dapat menghindari efek samping yang berkelanjutan, mengencerkan dahak yang kental dan kekuningan, serta mengatasi infeksi. Fisioterapi dada Cara ini dilakukan untuk mempermudah proses pengeluaran dahak dari paru. Meningkatkan daya tahan tubuh sangat penting untuk menghindarkan diri dari pneumonia. Karena itu, jagalah kebersihan diri dengan menerapkan hal-hal berikut dalam keseharian:Rajin mencuci tanganMengenakan masker ketika pergi ke tempat umumBerolahraga secara teratur."
mengatasi_PES="cara mengatasinya : Penanganan terhadap penyakit pes membutuhkan perawatan inap di rumah sakit. Dokter akan meresepkan antibiotik untuk membunuh bakteri, serta obat-obatan lain sesuai dengan tanda dan gejala yang dialami oleh penderita tersebut."
mengatasi_Kolera="cara mengatasinya : memperbanyak asupan cairan untuk mencegah dehidrasi akibat kolera Bila dehidrasi sudah diatasi, tujuan pengobatan selanjutnya adalah untuk menggantikan jumlah cairan yang hilang karena diare dan muntah. Pengobatan awal dengan tetrasiklin atau antibiotik lainnya bisa membunuh bakteri dan biasanya akan menghentikan diare dalam 48 jam.Bila berada di daerah resisten dengan wabah kolera atau Vibrio cholerae, dapat digunakan furozolidone. Makanan padat bisa diberikan setelah muntah-muntah berhenti dan nafsu makan sudah kembali.Pencegahan: Untuk mencegah kolera, penting untuk melakukan penjernihan cadangan air dan pembuangan tinja yang memenuhi standar. Selain itu, minumlah air yang sudah terlebih dahulu dimasak. Hindari mengonsumsi sayuran mentah atau ikan dan kerang yang tidak dimasak sampai matang.Pemberian antibiotik tetrasiklin juga bisa membantu mencegah penyakit pada orang-orang yang sama-sama menggunakan perabotan rumah dengan penderita kolera. Sementara itu, vaksinasi kolera tidak terlalu dianjurkan karena perlindungan yang diberikan tidak menyeluruh."


# print(context)
# cur.execute("SELECT nama_penyakit,'adalah penyakit yang mempunyai gejala', gejala, penyegahan, rekomendasi_rujukan.nama_tempat ,'terdekat => ', rekomendasi_rujukan.link_maps from input_dokter inner join rekomendasi_rujukan on input_dokter.rekomendasi_rujukan = rekomendasi_rujukan.nama_tempat ")
# fromdb = cur.fetchall()
# context = str(fromdb)
mengatasi_Sakit_kepala = "Cara penanganannya tergantung dari jenis sakit kepala, bisa dengan minum obat pereda nyeri seperti paracetamol atau melakukan teknik relaksasi."
mengatasi_Diare ="Cara penanganannya yaitu minum banyak air putih dan elektrolit, konsumsi makanan ringan seperti roti tawar, dan hindari makanan yang sulit dicerna."
mengatasi_Sakit_gigi = "Cara penanganannya yaitu berkumur dengan air garam hangat, minum obat pereda nyeri seperti paracetamol, dan memeriksakan diri ke dokter gigi jika diperlukan."
mengatasi_Sakit_perut = "Cara penanganannya tergantung dari penyebabnya, bisa dengan menghindari makanan yang sulit dicerna atau konsumsi obat pereda nyeri seperti paracetamol."
mengatasi_Sariawan ="Cara penanganannya yaitu berkumur dengan air garam, konsumsi makanan yang lunak, dan aplikasikan salep atau gel yang mengandung kortikosteroid."
mengatasi_Ruam_kulit = "Cara penanganannya tergantung dari penyebabnya, bisa dengan menghindari pemicu alergi atau konsumsi obat anti alergi."
mengatasi_Sakit_tenggorokan = "Cara penanganannya yaitu berkumur dengan air garam, minum banyak air putih, dan konsumsi obat pereda nyeri seperti paracetamol"
mengatasi_Gigitan_serangga = "Cara penanganannya yaitu membersihkan area yang digigit dengan air dan sabun, konsumsi obat pereda nyeri atau antihistamin, dan hindari menggaruk area yang digigit."
mengatasi_Sakit_pinggang = "Cara penanganannya yaitu istirahat yang cukup, pergi ke"

gmaps_rumah_sakit = "Rumah Sakit terdekat => "
gmaps_puskesmas = "Puskesmas terdekat => "
gmaps_apotek = "Apotek terdekat => "
gmaps_urut = "Tempat pijat / urut disekitar anda => "

link_rumah_sakit = "https://www.google.com/maps/search/Rumah_sakit/"
link_puskesmas = "https://www.google.com/maps/search/Puskesmas/"
link_apotek = "https://www.google.com/maps/search/Apotek/"
link_urut = "https://www.google.com/maps/search/Urut/"


def convertTuple1(tup):
    return ''.join([str(x) for x in tup])

# dari database

def bert_prediction(rules,question):
  respon_model = []
  dictlogs = {}
  penyakit_terdeteksi = []

  print(rules)
  print(question)
  list_gejala = question.split(",")
  gejala = []
  for string in list_gejala:
      new_string = string.strip()
      new_string = new_string.lower()
      gejala.append(new_string)
  print(gejala)
  matched_diseases = set()
  detailed_matched_diseases = set()
  for symptoms, disease in rules.items():
        matched_symptoms = sum(symptom in gejala for symptom in symptoms)
        print(matched_symptoms)
        if matched_symptoms == 1: # Ubah batas jumlah gejala yang cocok
            matched_diseases.add(disease)
        elif matched_symptoms >=2:
            detailed_matched_diseases.add(disease)
    
  list(matched_diseases) if matched_diseases else ['Tidak Diketahui']
  hasil_deteksi = list(matched_diseases)
  if hasil_deteksi ==[]:
    
    dictlogs.update({"status": False,"deskripsi": "maaf saya tidak tahu penyakit anda"})

  else:
    if len(detailed_matched_diseases)>0:
      jawaban = ', '.join(hasil_deteksi)+', '.join(detailed_matched_diseases)
      if "adalah" in jawaban:
        dictlogs.update({"status": True,"jawaban": ', '.join(hasil_deteksi)+', '.join(detailed_matched_diseases)})
      else:
        dictlogs.update({"status": True,"jawaban": "beberapa penyakit yang saya temukan berdasarkan 1 gejala anda yaitu: "+', '.join(hasil_deteksi)+" beberapa penyakit yang saya temukan berdasarkan 2 hingga semua gejala anda yaitu: "+', '.join(detailed_matched_diseases)})
    else:
      jawaban = ', '.join(hasil_deteksi)
      if "adalah" in jawaban:
        dictlogs.update({"status": True,"jawaban": ""+', '.join(hasil_deteksi)})
      else:
        dictlogs.update({"status": True,"jawaban": "beberapa penyakit yang saya temukan berdasarkan gejala anda yaitu: "+', '.join(hasil_deteksi)})

  respon_model.append(dictlogs)    
  
  return jsonify(respon_model)

def random_question(ask):
  prompt = (ask)

  completions = openai.Completion.create(
      engine="text-davinci-002",
      prompt=prompt,
      max_tokens=1024,
      n=1,
      stop=None,
      temperature=0.5,
  )

  message = completions.choices[0].text
  print(message)
  
  return message